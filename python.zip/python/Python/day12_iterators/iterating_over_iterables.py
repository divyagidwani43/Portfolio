# List iteration
numbers = [10, 20, 30]
for num in numbers:
    print(num)

it = iter(numbers)
print(next(it))  # 10
print(next(it))  # 20
print(next(it))  # 30

# Tuple iteration
fruits = ("apple", "banana", "cherry")
for fruit in fruits:
    print(fruit)

it = iter(fruits)
print(next(it))  # apple
print(next(it))  # banana
print(next(it))  # cherry

# Dictionary iteration
# this iterates over the dictionary
data = {"name": "Alice", "age": 25, "city": "New York"}
for key in data:
    print(key, "->", data[key])

for key, value in data.items():
    print(f"{key}: {value}")

it = iter(data)
print(next(it))  # name
print(next(it))  # age
print(next(it))  # city

it = iter(data)
print(data[next(it)])  # Alice
print(data[next(it)])  # 25
print(data[next(it)])  # New York

