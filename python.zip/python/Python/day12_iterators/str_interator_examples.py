# Write a program that manually iterates over a string without using a for loop (use iter() and next()).
class StringIterator:
    def __init__(self, string):
        self.string = string
        self.index = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.index >= len(self.string):
            raise StringIterator(string)
        result = self.string[self.index]
        self.index +=1
        return result
    
string =StringIterator("divya")

print(next(string))
print(next(string))
print(next(string))
print(next(string))
print(next(string))

# Create an iterator ReverseString that iterates over a string in reverse order.
class ReverseString:
    def __init__(self, string):
        self.string = string
        self.index = len(string) -1

    def __next__(self):
        if self.index < 0:
            raise StopIteration
        result = self.string[self.index]
        self.index -=1
        return result

rev=ReverseString("divya")
print(next(rev))
print(next(rev))
print(next(rev))
print(next(rev))
print(next(rev))


class VowelExtractor:
    def __init__(self, string):
        self.string = string
        self.index = 0
        self.vowels = "aeiouAEIOU"

    def __iter__(self):
        return self

    def __next__(self):
        while self.index < len(self.string):
            char = self.string[self.index]
            self.index += 1 
            if char in self.vowels:
                return char
        raise StopIteration  

vowels = VowelExtractor("divya")
print(next(vowels))  
print(next(vowels))  
