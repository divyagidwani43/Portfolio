# Write an iterator SquareNumbers that returns the square of numbers from 1 to n.
class SquareNumbers:
    def __init__(self, n):
        self.n = n
        self.i = 1

    def __iter__(self):
        return self

    def __next__(self):
        if self.i <= self.n:
            result = self.i * self.i
            self.i += 1
            return result
        else:
            raise StopIteration
        
square=SquareNumbers(10)
print(next(square))
print(next(square))
print(next(square))
print(next(square))
print(next(square))