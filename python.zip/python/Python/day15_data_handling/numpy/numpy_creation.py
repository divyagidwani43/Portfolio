import numpy
arr = numpy.array([1, 2, 3, 4, 5])
print(arr)

# NumPy is usually imported under the np alias.
import numpy as np
arr2 = np.array([1, 2, 3, 4, 5, 6, 7]) # NumPy ndarray Object
print(arr2)

# Use a tuple to create a NumPy array:
arr3 = np.array((1, 2, 3, 4, 5))
print(arr3)

# Dimensions in Arrays
# 0-D Arrays
arr4 = np.array(42)
print(arr4)

# 1-D Arrays
arr5 = np.array([1, 2, 3, 4, 5])
print(arr5)

# 2-D Arrays
arr6 = np.array([[1, 2, 3], [4, 5, 6]])
print(arr6)

# 3-D arrays
arr7 = np.array([[[1, 2, 3], [4, 5, 6]], [[1, 2, 3], [4, 5, 6]]])
print(arr7)

# Check Number of Dimensions
print(arr4.ndim)
print(arr5.ndim)
print(arr6.ndim)
print(arr7.ndim)

# Higher Dimensional Arrays
arr8 = np.array([1, 2, 3, 4], ndmin=5)
print(arr8)
print('number of dimensions :', arr8.ndim)
