import numpy as np
# Searching Arrays
arr50 = np.array([1, 2, 3, 4, 5, 4, 4])
x = np.where(arr50 == 4)
print(x)

# NumPy Sorting Arrays
arr51 = np.array([3, 2, 0, 1])
print(np.sort(arr51))
arr52 = np.array(['banana', 'cherry', 'apple'])
print(np.sort(arr52))
arr53 = np.array([True, False, True])
print(np.sort(arr53))
arr54 = np.array([[3, 2, 4], [5, 0, 1]])
print(np.sort(arr54))

# NumPy Filter Array
arr55 = np.array([41, 42, 43, 44])
filter_arr = arr55 > 42
newarr = arr55[filter_arr]
print(filter_arr)
print(newarr)