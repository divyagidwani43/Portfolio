import numpy as np

# NumPy Array Shape
arr23 = np.array([[1, 2, 3, 4], [5, 6, 7, 8]])
print(arr23.shape)
arr24 = np.array([1, 2, 3, 4], ndmin=5)
print(arr24)
print('shape of array :', arr24.shape)

# NumPy Array Reshaping
arr25= np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
newarr3 = arr25.reshape(4, 3)
print(newarr3)
newarr4 = arr25.reshape(2, 3, 2)
print(newarr4)
arr26 = np.array([1, 2, 3, 4, 5, 6, 7, 8])
newarr5 = arr26.reshape(2, 2, -1)
print(newarr5)

# Flattening the arrays
arr27 = np.array([[1, 2, 3], [4, 5, 6]])
newarr6 = arr27.reshape(-1)
print(newarr6)
