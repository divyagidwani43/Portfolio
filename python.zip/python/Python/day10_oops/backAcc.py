class BankAccount:
    """A simple bank account class with deposit, withdrawal, and balance checking functionality."""
    
    def __init__(self):
        """Initialize the bank account with a private balance attribute set to 0."""
        self.__balance = 0  

    def deposit(self, amount):
        """Deposit a positive amount into the account."""
        if amount > 0:
            self.__balance += amount
        else:
            print("Deposit amount must be positive.")

    def withdraw(self, amount):
        """Withdraw a specified amount if sufficient funds are available."""
        if amount > 0:
            if amount <= self.__balance:
                self.__balance -= amount
            else:
                print("Insufficient funds.")
        else:
            print("Withdrawal amount must be positive.")
    
    def get_balance(self):
        """Return the current balance of the account."""
        return self.__balance
    
# Testing the class
account = BankAccount()
account.deposit(100)
print(account.get_balance())  # Output: 100
account.withdraw(50)
print(account.get_balance())  # Output: 50
account.withdraw(100)  # Output: Insufficient funds.
print(account.get_balance())  # Output: 50
account.deposit(-10)  # Output: Deposit amount must be positive.
account.withdraw(-20)  # Output: Withdrawal amount must be positive.
