# Understanding Lists in Python

# 1. Creating Lists
l1 = [1, 2, "Hi", 4]
print("Original List:", l1)  # Output: [1, 2, 'Hi', 4]

# 2. Accessing List Members
print("First Element:", l1[0])  # Output: 1
print("Third Element:", l1[2])  # Output: Hi

# 3. Modifying List Elements
l1[2] = "Hello"  # Changing "Hi" to "Hello"
print("Modified List:", l1)  # Output: [1, 2, 'Hello', 4]

# 4. Adding Elements to a List
l1.append(9)  # Adding 9 to the end of the list
print("List after append:", l1)  # Output: [1, 2, 'Hello', 4, 9]

l1.insert(2, "New Element")  # Inserting an element at index 2
print("List after insert:", l1)  # Output: [1, 2, 'New Element', 'Hello', 4, 9]

# 5. List Slicing
print("Sliced List [0:5:2]:", l1[0:5:2])  # Output: [1, 'New Element', 4]

# 6. Removing Elements from a List
l1.pop()  # Removing the last element (9)
print("List after pop:", l1)  # Output: [1, 2, 'New Element', 'Hello', 4]

l1.remove(1)  # Removing the first occurrence of 1
print("List after remove:", l1)  # Output: [2, 'New Element', 'Hello', 4]

# 7.1 Length of List
print("Length of the list:", len(l1))  # Output: 4

# 7.2 Concatenating Lists
l2 = [10, 20]
l3 = [30, 40]
l3 = l2 + l3  # Concatenating l2 and l3
print("Concatenated List:", l3)  # Output: [10, 20, 30, 40]

# 7.3 Repeating Lists
l4 = l1 * 2  # Repeating the list twice
print("Repeated List:", l4)  # Output: [2, 'New Element', 'Hello', 4, 2, 'New Element', 'Hello', 4]

# 7.4 Checking if an Element Exists in the List
print("Is 4 in the list?", 4 in l1)  # Output: True
print("Is 'Hi' in the list?", "Hi" in l1)  # Output: False

# 7.5 Finding Index of an Element
print("Index of 'Hello':", l1.index("Hello"))  # Output: 2

# 7.6 Sorting a List
l5 = [3, 1, 4, 2]
l5.sort()  # Sorting the list
print("Sorted List:", l5)  # Output: [1, 2, 3, 4]

l5.sort(reverse=True)  # Sorting the list in descending order
print("Sorted List in Descending Order:", l5)  # Output: [4, 3, 2, 1]

# 7.7 Reversing a List
l5.reverse()  # Reversing the list
print("Reversed List:", l5)  # Output: [4, 3, 2, 1]

# 7.8 Clearing a List
l5.clear()  # Removing all elements from the list
print("Cleared List:", l5)  # Output: []

# 7.9 finding max
numbers = [10, 20, 30, 40, 50]
max_num = max(numbers)
min_num = min(numbers)
print("Maximum number:", max_num)
print("Minimum number:", min_num)

# Task 3: Create a list of 6 names. Add one more name to the list, then remove the second name from the list and print the modified list.
names = ["John", "Alice", "Bob", "Charlie", "David", "Eve"]
# solu
names.append("Grace")
names.remove("Alice")  
print(names)

# Task 4: Given the list fruits = ["apple", "banana", "cherry"], check if "apple" is in the list. If it is, print a message that says "apple is in the list".
fruits = ["apple", "banana", "cherry"]
if "apple" in fruits:
    print("apple is in the list")
else:
    print("apple is not in the list")
    
# Task 5: Create a list of 5 random numbers. Sort the list in ascending order and then reverse it to show the numbers in descending order.
numbers = [15, 7, 22, 9, 14]
numbers.sort()
numbers.reverse()  
print("Sorted in descending order:", numbers)
# another way
numbers2 = [15, 7, 22, 9, 14]
numbers2.sort(reverse=True)
print(numbers)