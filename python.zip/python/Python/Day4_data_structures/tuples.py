# Understanding Tuples in Python

# Creating Tuples
my_tuple = (1, 2, 3, 4)
print("Tuple:", my_tuple)  # Output: (1, 2, 3, 4)

# Tuple with different data types
mixed_tuple = (1, "hello", 3.14, True)
print("Mixed Tuple:", mixed_tuple)  # Output: (1, 'hello', 3.14, True)

# Tuple without parentheses (Packing)
packed_tuple = 5, 10, 15
print("Packed Tuple:", packed_tuple)  # Output: (5, 10, 15)

# Accessing Elements
print("First Element:", my_tuple[0])  # Output: 1
print("Last Element:", my_tuple[-1])  # Output: 4

# Slicing a Tuple
print("Slice [1:3]:", my_tuple[1:3])  # Output: (2, 3)
print("Slice [:2]:", my_tuple[:2])    # Output: (1, 2)
print("Slice [2:]:", my_tuple[2:])    # Output: (3, 4)

# Tuples are Immutable
try:
    my_tuple[0] = 100  # This will raise an error
except TypeError as e:
    print("Error:", e)  # Output: Error: 'tuple' object does not support item assignment

# Tuple Unpacking
a, b, c = (10, 20, 30)
print("Unpacked Values:", a, b, c)  # Output: 10 20 30

# Skipping a value using _
x, _, z = (5, 15, 25)
print("Skipped Middle Value:", x, z)  # Output: 5 25

# Tuple Methods
sample_tuple = (1, 2, 3, 1, 4, 1)
print("Count of 1:", sample_tuple.count(1))  # Output: 3
# accessing how many times 1 occurs
print("Index of 3:", sample_tuple.index(3))  # Output: 2
# what is index of 3

# Using Tuples as Dictionary Keys
coordinates = {
    "Point A": (10.5, 20.6),
    "Point B": (5.2, 15.8)
}

# Accessing the coordinates of "Point A"
print(coordinates["Point A"])  # Output: (10.5, 20.6)


# Looping Through a Tuple
print("\nLooping through my_tuple:")
for value in my_tuple:
    print(value)  # Output: 1 2 3 4

# Tasks 

# Task 1: Create a tuple with 5 elements and print each one using a loop.
print("Task 1")
your_tuple = (100, 200, 300, 400, 500)
for num in your_tuple:
    print(num)  


# Task 2: Try tuple unpacking with 4 values.
p, q, r, s = (10, 20, 30, 40)
print("Task 2:", p, q, r, s)  

# Task 3: Create a tuple and count how many times a number appears in it.
test_tuple = (1, 2, 2, 3, 4, 2, 5, 6, 2)
print("Number 2 appears", test_tuple.count(2), "times.")  

# Original tuple
tuple1 = (1, 2, 3)

# Adding an element by creating a new tuple
tuple1 = tuple1 + (4,)

print(tuple1)
# Output: (1, 2, 3, 4)