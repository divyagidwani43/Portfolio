name= ["divya","nikhil","sarika"]
age=[21,26,37]

for i in range(len(name)):
    print(f"{name[i]}  {age[i]}")

# ask for input then loop 
a=input("number of time loop must run: ")
for i in range(int(a)):
    print(f"{i} times")

# user guve 2 nums and print calc of them
operator=input("Enter an operator (+ - * /): ")
num1=input("Enter the first number: ")
num2=input("Enter the second number: ")
if(operator=="/"):
    if(num2=="0"):
        print("Cannot divide by zero")
    else:
        print(f"{num1} {operator} {num2} = {int(num1)/int(num2)}")
elif(operator=="*"):
    print(f"{num1} {operator} {num2} = {int(num1)*int(num2)}")
elif(operator=="+"):
    print(f"{num1} {operator} {num2} = {int(num1)+int(num2)}")  
elif(operator=="-"):
    print(f"{num1} {operator} {num2} = {int(num1)-int(num2)}")
