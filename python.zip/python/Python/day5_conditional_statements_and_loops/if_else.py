a = 10 
if a > 5:  #condition if 'a' is greater than 5
    print("A is greater than 5")  # Prints message if condition is True
# No 'else' statement, so nothing happens if the condition is False


# if-else
# if condition:
    # code to execute if condition is True
# else:
    # code to execute if condition is False
b = 3
if b > 5:
    print("b is greater than 5")
else:
    print("b is not greater than 5")


# elif
c = 7
if c > 10:
    print("c is greater than 10")
elif c == 7:
    # same as else if
    print("c is equal to 7")
else:
    print("c is less than 7")


# Nested if Statements
d = 15
if d > 10:
    print("d is greater than 10")
    if d > 20:
        print("d is also greater than 20")
    else:
        print("d is not greater than 20")


# Using Logical Operators
e = 8
if e > 5 and e < 10:
    print("e is between 5 and 10")

f = 12
if f < 5 or f > 10:
    print("f is either less than 5 or greater than 10")

g = False
if not g:
    print("g is False")


# Ternary Conditional Operator
# This is a compact form of 'if-else' that evaluates the condition in a single line.
# Syntax: value_if_true if condition else value_if_false
# It is also known as the conditional expression or inline if-else
# Example:
# result = "value is True" if condition else "value is False"
h = 7
result = "h is greater than 5" if h > 5 else "h is not greater than 5"
print(result)


# if Statements with Multiple Conditions
i = 9
if (i > 5 and i < 10) or i == 20:
    print("i is either between 5 and 10 or equal to 20")


# Check if a string is empty
s = ""
if not s:
    print("The string is empty")
else:
    print("The string is not empty")

# Check if a list contains a specific element
lst = [1, 2, 3]
if 2 in lst:
    print("The list contains 2")
else:
    print("The list does not contain 2")