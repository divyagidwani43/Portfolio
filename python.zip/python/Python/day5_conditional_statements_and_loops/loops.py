for i in range(5):  # Loops from 0 to 4 not include 5
    print(i)
print("") #blank line


for i in range(1,5):  # Loops from 1 to 4 not include 5
    print(i)
print("") #blank line


for i in range(0,11,2):  # will run from 0 to 10 and skip 2 numbers
    print(i)
print("") #blank line


fruits = ["apple", "banana", "cherry"] #loop through a list and stop when list ends
for fruit in fruits:
    print(fruit)


x = 0
print("") #blank line
while x < 5:
    print(x)
    x += 1  # Increment x to avoid an infinite loop


# BREAK
# Stop the loop if x equals 3
print("")  
print("Stop the loop if x equals 3")  
for i in range(5):  # Loops from 0 to 4
    if i == 3:
        print("Breaking the loop at i =", i)
        break  # Exit the loop when i equals 3
    print(i) #when i not 3 and less than 3


print("")  
print("Skip iteration if x is 2") 
for i in range(5):  
    if i == 2:
        print("Skipping i =", i)
        continue  #wont break but skip only
    print(i)


print("")  
print("loop without break") 
for i in range(5):
    print(i)
else:
    print("Loop completed without breaking.")


print("")  
# While loop example with 'break' and 'else'
print("While loop example with 'break' and 'else") 
x = 0
while x < 5:
    if x == 3:
        print("Breaking the while loop at x =", x)
        break  # Exit the loop when x equals 3
    print(x)
    x += 1  # Increment x to avoid an infinite loop
else:
    print("While loop completed without breaking.") 


# Using zip to iterate over multiple lists simultaneously
names = ["Alice", "Bob", "Charlie"]
ages = [25, 30, 35]
for name, age in zip(names, ages):
    print(f"{name} is {age} years old")
print("")