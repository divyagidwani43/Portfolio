# = (Simple assignment): Assigns a value to a variable.
x = 5

# += (Addition assignment): Adds the right operand to the left operand and assigns the result to the left operand.
x += 3

# -= (Subtraction assignment): Subtracts the right operand from the left operand and assigns the result to the left operand.
x -= 2

# *= (Multiplication assignment): Multiplies the left operand by the right operand and assigns the result to the left operand.
x *= 2

# /= (Division assignment): Divides the left operand by the right operand and assigns the result to the left operand.
x /= 2

# //= (Floor division assignment): Performs floor division and assigns the result to the left operand.
x //= 2

# %= (Modulo assignment): Computes the remainder and assigns the result to the left operand.
x %= 2

# **= (Exponentiation assignment): Performs exponentiation and assigns the result to the left operand.
x **= 2

# += (Addition assignment): Adds the right operand to the left operand and assigns the result to the left operand.
x += 3
