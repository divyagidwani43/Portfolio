import re

"""
Pattern Matching Functions in Python's re module:

re.match()   → Matches at the beginning of a string
re.search()  → Searches anywhere in the string
re.findall() → Finds all occurrences of a pattern
re.finditer() → Returns an iterator of match objects
"""

# re.match() → Matches at the beginning of a string
s1 = "Python is fun!"
p1 = r"Python"
match_result = re.match(p1, s1)
if match_result:
    print("re.match():", match_result.group())  
else:
    print("re.match(): No match")


# re.search() → Searches anywhere in the string
s2 = "I love Python programming."
p2 = r"Python"
search_result = re.search(p2, s2)
if search_result:
    print("re.search():", search_result.group())
else:
    print("re.search(): No match")


# re.findall() → Finds all occurrences of a pattern
s3 = "cat, cater, uhuvc, category, catastrophe"
p3 = r"cat"
findall_result = re.findall(p3, s3)
if findall_result:
    print("re.findall():", findall_result)  
else:
    print("re.findall(): No matches found")


# re.finditer() → Returns an iterator of match objects
s4 = "Email: test@example.com, support@example.org uhu"
p4 = r"[\w.-]+@[\w.-]+\.\w+"
finditer_result = list(re.finditer(p4, s4))  # Convert iterator to list
if finditer_result:
    print("re.finditer():", [match.group() for match in finditer_result])  
else:
    print("re.finditer(): No matches found")



"""
Modifying Strings with Regex:
re.sub()   → Replace substrings based on a pattern
re.split() → Split a string based on a pattern
"""

# re.sub() → Replace substrings based on a pattern
s1 = "I love Python and JavaScript."
p1 = r"JavaScript"
replacement = "C++"
sub_result = re.sub(p1, replacement, s1)
print("re.sub():", sub_result)  # Output: I love Python and C++.


# re.sub() with a regex pattern
s2 = "My phone number is 123-456-7890."
p2 = r"\d"  # Replace all digits
sub_result2 = re.sub(p2, "*", s2)
print("re.sub() with pattern:", sub_result2)  


# re.split() → Split a string based on a pattern
s3 = "apple, orange; banana|grape"
p3 = r"[,;|]"  # Split on commas, semicolons, or pipes
split_result = re.split(p3, s3)
print("re.split():", split_result)  


# re.split() with whitespace pattern
s4 = "Hello   World!  How are   you?"
p4 = r"\s+"  # Split on one or more spaces
split_result2 = re.split(p4, s4)
print("re.split() with pattern:", split_result2)  