import re

"""
re.findall() is a function in the re module that finds all occurrences of a pattern in a string and returns them as a list.
Syntax of re.findall()
re.findall(pattern, string)
pattern → The regex pattern to search for
string → The text where the pattern is searched
Returns: A list of all matches found
"""

# Matches any digit (0-9)
s1 = "The price is 2500 dollars."
digits = re.findall(r"\d.", s1)  
digits2 = re.findall(r"\d+", s1)  
digits3 = re.findall(r"\d*", s1)  
print("Digits:", digits)
print("Digits:", digits2)
print("Digits:", digits3)

# Matches any word character (letters, digits, underscore _)
s2 = "Hello_123! 67"
words = re.findall(r"\w+", s2)  
print("Word characters:", words)

# Matches any whitespace character (spaces, tabs, newlines)
s3 = "Hello Wor ld!"
whitespace_chars = re.findall(r"\s", s3)  
print("Whitespace:", whitespace_chars)

# Matches any character except newline
s4 = "a1b2c3"
pattern1 = re.findall(r"a...c", s4)  
pattern2 = re.findall(r"a.c", s4)  
pattern3 = re.findall(r"a.b", s4)  
print("\"a...c\"", pattern1)
print("\"a.c\"", pattern2)
print("\"a.b\"", pattern3)

# Matches the start of the string ^
s5 = "Hello world! he hello"
start_hello = re.findall(r"^Hello", s5)
start_hi = re.findall(r"^hi", s5)
print("Starts with 'Hello':", start_hello)
print("Starts with 'hi':", start_hi)

# Matches the end of the string
s6 = "Welcome to Python"
ends_python = re.findall(r"Python$", s6)
print("Ends with 'Python':", ends_python)

# Matches 0 or more occurrences
s7 = "AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaabbbbbbhAaaaaa!"
zero_or_more = re.findall(r"Aa*", s7)  
print("0 or more occurrences:", zero_or_more)

# Matches 1 or more occurrences
s8 = "go go go go goal"
one_or_more = re.findall(r"go+", s8)  
print("1 or more occurrences:", one_or_more)

# Matches 0 or 1 occurrence
s9 = "colouur collor color colour coor"  # Also works for "colour"
zero_or_one = re.findall(r"col?ou?r", s9)  
print("0 or 1 occurrence:", zero_or_one)

# Matches between n and m occurrences
s10 = "Hellooo!"
between_n_m = re.findall(r"o{2,4}", s10)  
print("Between 2 and 3 occurrences:", between_n_m)

# Matches any character inside the brackets
s11 = "apple orange banana"
vowels = re.findall(r"[aeiou]", s11)  
print("Character set (vowels):", vowels)

# Alternation (OR operator)
s12 = "cat and dog and cat and dog and rat are friends"
alternation = re.findall(r"cat|dog", s12)  
print("Alternation (OR):", alternation)

# Grouping in regex
s13 = "John Doe, Jane Smith"
grouped_names = re.findall(r"((\w+) (\w+))+", s13)  
print("Grouping:", grouped_names)
