# SPECIAL METHODS (__str__, __repr__, __len__)
class Book:
    """Class demonstrating special methods."""
    def __init__(self, title, pages):
        self.title = title
        self.pages = pages
    
    """ 
    __str__ method should return a string because it is used to return a string representation of an object.
    another way to return a string representation of an object is to use the str() function.
    """
    def __str__(self):
        print(f"Book: {self.title}, Pages: {self.pages}")
        return f"Book: {self.title}, Pages: {self.pages}"
    
    """__repr__ method should return a string because it is used to return a string representation of an object.
    another way to return a string representation of an object is to use the repr() function.
    """
    def __repr__(self):
        print(f"Book('{self.title}', {self.pages})")
        return f"Book('{self.title}', {self.pages})"
        #return self.pages # This will raise an error because __repr__ should return a string.
    
    """
    __len__ method should return an integer because it is used to return the length of an object.
    another way to return the length of an object is to use the len() function.
    """
    def __len__(self):
        print(f"Number of pages: {self.pages}")
        return self.pages
    
    def __del__(self):
        print(f"Book '{self.title}' has been deleted.")


book = Book("Python Programming", 450)
book.__str__() # Calls __str__
str(book)   # another way to call __str__ and it returns the string representation of the object. 

book.__repr__() # Calls __repr__ and it returns the string representation of the object.
repr(book) # another way to call __repr__ and it returns the string representation of the object.

book.__len__()  # Calls __len__ and it returns the number of pages
len(book) # Calls __len__ and it returns the number of pages


# another class without __str__, __repr__ and __len__ methods
class Car:
    def __init__(self, model, year):
        self.model = model
        self.year = year
    
    def __del__(self):
        print(f"Car '{self.model}' has been deleted.")

#using str,repr and len functions
car = Car("Toyota", 2020)
print(str(car)) # Calls __str__ because Python provides a default implementation for __str__() and __repr__(), but not for __len__().
print(repr(car)) # Calls __repr__ 
# len(car) #len will error because __len__ method is not defined in the Car class.