# Comments start with a #, and Python will render the rest of the line as a comment:
# comment for the sake of dummy commit

"""
This is a comment
written in
more than just one line
"""