print("Hello")

# if 1 > 2:
# print("Five is greater than two!")
#error due ti indentation
