x = 5
y = "Hello, World!"
# Python has no command for declaring a variable.

print(x)
print(y)

z = 4       # z is of type int
z = "Sally" # z is now of type str
print(z)
print(type(z)) #You can get the data type of a variable with the type() function.


a = 4
A = "Sally"
#A will not overwrite a


# Python allows you to assign values to multiple variables in one line
a, b, c = "Orange", "Banana", "Cherrb"
print(a)
print(b)
print(c)

# One Value to Multiple Variables
d = e = f = "Orange"
