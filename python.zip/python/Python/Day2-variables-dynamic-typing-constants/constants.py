# Python does not have a built-in keyword for defining constants like some other languages
PH= 3.4
print(PH)
PH=5
print(PH)
# the convention in Python is to use uppercase variable names to indicate that a variable is meant to be constant
# Although you can technically change the value of these variables in Python, doing so goes against the convention and can lead to confusion.


# Using collections.namedtuple (For fixed values)
from collections import namedtuple

Constants = namedtuple('Constants', 'PI MAX_USERS')

# Creating the constant object
constants = Constants(PI=3.14159, MAX_USERS=1000)

# Accessing the values
print(constants.PI)
print(constants.MAX_USERS)

# Trying to modify will raise an AttributeError
# constants.PI = 3.14  # This would raise an error
