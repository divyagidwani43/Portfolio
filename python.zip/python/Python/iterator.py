# Write an iterator SquareNumbers that returns the square of numbers from 1 to n.

# How do you manually iterate over an iterator using next()?
itera=[2,3,4,5]
iterat=iter(itera)
print(next(iterat))
print(next(iterat))
print(next(iterat))

# Create a custom iterator that generates numbers from 1 to 5.
class gene:
    def __init__(self,n):
        self.n=n
        self.i=1
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if(self.i<=self.n):
            print(self.i)
            self.i+=1
        else:
            print("range out")

gener=gene(5)
next(gener)
next(gener)
next(gener)
next(gener)
next(gener)
next(gener)
next(gener)

    
# Use an iterator to print only even numbers from a list.
class even:
    def __init__(self,n):
        self.n=n
        self.i=1

    def __iter__(self):
        return self
    
    def __next__(self):
        # print(self.i)
        if(self.i%2==0 and self.i<=self.n):
            print(self.i)
        self.i+=1

evens=even(12)
next(evens)
next(evens)
next(evens)
next(evens)