def repeat_twice(func):
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs) + " " + func(*args, **kwargs)
    return wrapper

@repeat_twice
def say_hello(name):
    return f"Hello, {name}"

print(say_hello("Alice"))  


def decorator_with_args(func):
    def wrapper(*args, **kwargs):
        print(f"Calling {func.__name__} with arguments {args} {kwargs}")
        result = func(*args, **kwargs)
        print(f"Finished executing {func.__name__}")
        return result
    return wrapper

@decorator_with_args
def add(a, b):
    return a + b

print(add(3, 5))

def repeat(n):  # Outer function (takes arguments)
    def decorator(func):  # Actual decorator
        def wrapper(*args, **kwargs):  # Inner wrapper
            for _ in range(n):
                func(*args, **kwargs)
        return wrapper
    return decorator  # Return the decorator itself

@repeat(3)  # Passing 3 as an argument to the decorator
def greet():
    print("Hello, Python!")
greet()


"""
Create a decorator @run_if(condition) that:
Takes a Boolean argument (condition).
If condition is True, the function executes normally.
If condition is False, it prints "Function skipped!" instead of running the function.
"""
def run_if(condition):
    def decorator(func):
        def wrapper(*args, **kwargs):
            if condition:
                return func(*args, **kwargs)
            else:
                print("Function skipped!")
        return wrapper
    return decorator

@run_if(True)  
def greet(name):
    print(f"Hello, {name}!")

@run_if(False)  
def farewell(name):
    print(f"Goodbye, {name}!")

greet("Alice")  
farewell("Bob")  

""" Checking if a Number is Even"""
class odd_even:
    @staticmethod
    def is_even(number):
        return number % 2 == 0

print(odd_even.is_even(10))  
print(odd_even.is_even(7))   

"""
Create a class-based decorator @Uppercase that makes function output uppercase.
"""
def Uppercase(func):
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        return result.upper()
    return wrapper

@Uppercase
def greet():
    return "hello"
print(greet())  # Output: HELLO

@Uppercase
def say_hello(name):
    return f"Hello, {name}!"
print(say_hello("Alice"))  # Output: HELLO, ALICE
print(say_hello("Alice"))  # Output: HELLO, ALICE

para="La tecnología ha transformado la forma en que vivimos, trabajamos y nos comunicamos. Desde los teléfonos inteligentes hasta la inteligencia artificial, los avances tecnológicos siguen dando forma a nuestra vida diaria. Internet ha hecho que la información sea más accesible que nunca, conectando a personas de todo el mundo al instante."
@Uppercase
def book(book_para):
    return f"para el libro: {book_para}"
print(book(para))

"""
Create a decorator @AddPrefix("Prefix: ") that adds a prefix to a function’s output.
"""
def AddPrefix(prefix):
    def decorator(func):
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            return f"{prefix}{result}"
        return wrapper
    return decorator  

@AddPrefix("INFO: ")
def message():
    return "This is a log message."

print(message())  