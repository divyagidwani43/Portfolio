# Define a __call__() method – This makes the instance callable like a function.
# Use self to store state – This allows tracking of function calls or modifying behavior dynamically.

class Example:
    def __call__(self):
        print("Instance is now callable!")

obj = Example()
obj()  # Works like a function!
# Now, obj() calls __call__() automatically.


class CallCounter:
    def __init__(self, func):
        self.func = func
        self.count = 0  

    def __call__(self, *args, **kwargs):
        self.count += 1
        print(f"Function '{self.func.__name__}' called {self.count} times")
        return self.func(*args, **kwargs)  # Execute the original function

@CallCounter
def greet(name):
    print(f"Hello, {name}!")

greet("Alice")
greet("Bob")
greet("Charlie")


class UpperCase:
    def __init__(self, func):
        self.func = func  

    def __call__(self, *args, **kwargs):
        result = self.func(*args, **kwargs)
        return result.upper()

class Exclaim:
    def __init__(self, func):
        self.func = func  

    def __call__(self, *args, **kwargs):
        return self.func(*args, **kwargs) + "!"

@Exclaim
@UpperCase
def message():
    return "hello world"

print(message())  

"""
Create a class-based decorator that limits the number of times a function can be called.
If exceeded, print a warning.
"""
class LimitCalls:
    def __init__(self, n):
        self.max_calls = n  
        self.count = 0  

    def __call__(self, func):
        def wrapper(*args, **kwargs):
            self.count += 1
            if self.count > self.max_calls:
                print(f"Function '{func.__name__}' call limit exceeded ({self.max_calls} times)")
                return  # Stop execution after limit
            return func(*args, **kwargs)  # Execute function normally
        return wrapper

@LimitCalls(3)
def lim():
    print("hi")

lim()  # Output: hi
lim()  # Output: hi
lim()  # Output: hi
lim()  # Output: Function 'lim' call limit exceeded (3 times)
lim()  # Output: Function 'lim' call limit exceeded (3 times)
