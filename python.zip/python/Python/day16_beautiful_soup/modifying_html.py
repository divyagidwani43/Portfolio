from bs4 import BeautifulSoup

# Sample HTML document
html_doc = """
<html>
    <head>
        <title>Original Title</title>
    </head>
    <body>
        <h1>Main Heading</h1>
        <p class="intro">This is an introduction paragraph.</p>
        <p>This is another paragraph.</p>

        <div class="content">
            <ul>
                <li>Item 1</li>
                <li>Item 2</li>
                <li>Item 3</li>
            </ul>
        </div>

        <footer>
            <p>Contact: email@example.com</p>
        </footer>
    </body>
</html>
"""

# Create a BeautifulSoup object
soup = BeautifulSoup(html_doc, "html.parser")

# Prettify (Format) the Original HTML
print("🔹 Original HTML:\n")
print(soup.prettify())

# Modifying Text Content
print("\n🔹 Modifying Text Content:\n")

# Modify the title text
soup.title.string = "Updated Title"

# Modify paragraph text
soup.find("p", class_="intro").string = "Updated Introduction Paragraph"

# Modify the footer text
soup.footer.p.string = "Updated Contact: newemail@example.com"

print(soup.prettify())

# Inserting New Elements
print("\n🔹 Inserting New Elements:\n")

# Insert a new <h2> element before the first paragraph
new_h2 = soup.new_tag("h2")
new_h2.string = "Subheading Added"
soup.body.insert(1, new_h2)

# Insert a new paragraph after the existing one
new_p = soup.new_tag("p")
new_p.string = "This is an additional paragraph."
soup.body.insert(4, new_p)

print(soup.prettify())

# Replacing an Element
print("\n🔹 Replacing an Element:\n")

# Replace an existing paragraph with a new one
new_paragraph = soup.new_tag("p")
new_paragraph.string = "This paragraph replaces the previous one."
soup.find("p", class_="intro").replace_with(new_paragraph)

print(soup.prettify())

# Removing an Element
print("\n🔹 Removing an Element:\n")

# Remove the last <li> item from the list
soup.find_all("li")[-1].decompose()

# Remove the footer
soup.footer.decompose()

print(soup.prettify())

# Adding New Attributes
print("\n🔹 Adding New Attributes:\n")

# Add an ID to the first <p> tag
soup.find("p").attrs["id"] = "first-paragraph"

# Add a class to the <ul> tag
soup.find("ul")["class"] = "styled-list"

# Add a custom attribute to <h1>
soup.h1["data-custom"] = "header-info"

print(soup.prettify())

# Wrapping an Element Inside Another Tag
print("\n🔹 Wrapping an Element:\n")

# Wrap the first paragraph inside a <div>
wrapper_div = soup.new_tag("div", class_="wrapper")
soup.find("p").wrap(wrapper_div)

print(soup.prettify())

# Unwrapping an Element (Removing its tag but keeping the content)
print("\n🔹 Unwrapping an Element:\n")

# Unwrap the first <ul> (removes <ul> but keeps <li> items)
soup.find("ul").unwrap()

print(soup.prettify())

# Appending Content Inside an Element
print("\n🔹 Appending Content:\n")

# Append a new <li> item inside the list
new_list_item = soup.new_tag("li")
new_list_item.string = "Item 4"
soup.find("div", class_="content").ul.append(new_list_item)

print(soup.prettify())
