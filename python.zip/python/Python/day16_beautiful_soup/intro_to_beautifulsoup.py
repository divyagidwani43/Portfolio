from bs4 import BeautifulSoup

# Sample HTML document
html_doc = "<html><head><title>Welcome to Web Scraping</title></head><body><p>Hello, World!</p></body></html>"

# Create a BeautifulSoup object
soup = BeautifulSoup(html_doc, "html.parser")

# Print formatted HTML
print(soup.prettify())
