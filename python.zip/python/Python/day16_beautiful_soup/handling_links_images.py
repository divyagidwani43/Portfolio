from bs4 import BeautifulSoup

# Sample HTML document with multiple links and images
html_doc = """
<html>
    <head>
        <title>Links and Images Example</title>
    </head>
    <body>
        <h1>Welcome to My Website</h1>
        
        <p>Here are some useful links:</p>
        <div class="links">
            <a href="https://example.com/page1" target="_blank">Visit Page 1</a>
            <a href="https://example.com/page2">Visit Page 2</a>
            <a href="https://example.com/contact" id="contact-link">Contact Us</a>
        </div>

        <p>Below are some images:</p>
        <div class="images">
            <img src="image1.jpg" alt="First Image">
            <img src="image2.png" alt="Second Image">
            <img src="https://example.com/external-image.jpg" alt="External Image">
        </div>

        <footer>
            <a href="https://example.com/privacy-policy">Privacy Policy</a>
            <a href="https://example.com/terms">Terms of Service</a>
        </footer>
    </body>
</html>
"""

# Create a BeautifulSoup object
soup = BeautifulSoup(html_doc, "html.parser")

# Extracting and Printing All Links
print("\n🔹 Extracting All Links:")

# Find all <a> tags
all_links = soup.find_all("a")
for i, link in enumerate(all_links, start=1):
    href = link.get("href")  # Extract href attribute
    text = link.text.strip()  # Extract link text
    print(f"{i}. Text: '{text}', URL: {href}")

# Extracting Links with Specific Attributes
print("\n🔹 Extracting Links with Specific Attributes:")

# Extract link with ID "contact-link"
contact_link = soup.find("a", id="contact-link")
if contact_link:
    print(f"Contact Link: {contact_link.get('href')}")

# Extract all external links (those with target="_blank")
external_links = soup.find_all("a", attrs={"target": "_blank"})
for ext_link in external_links:
    print(f"External Link: {ext_link.get('href')}")

# Extracting and Printing All Images
print("\n🔹 Extracting All Image Sources:")

# Find all <img> tags
all_images = soup.find_all("img")
for i, img in enumerate(all_images, start=1):
    img_src = img.get("src")  # Extract src attribute
    img_alt = img.get("alt", "No Alt Text")  # Extract alt attribute (if available)
    print(f"{i}. Image Source: {img_src}, Alt: {img_alt}")

# Extracting Only Local and External Images
print("\n🔹 Filtering Local and External Images:")

local_images = [img.get("src") for img in all_images if not img.get("src").startswith("http")]
external_images = [img.get("src") for img in all_images if img.get("src").startswith("http")]

print(f"Local Images: {local_images}")
print(f"External Images: {external_images}")

# Counting Elements
print("\n🔹 Counting Links and Images:")

num_links = len(all_links)
num_images = len(all_images)

print(f"Total Links: {num_links}")
print(f"Total Images: {num_images}")

# Extracting All Links & Images into a List
links_data = [{"text": link.text.strip(), "url": link.get("href")} for link in all_links]
images_data = [{"src": img.get("src"), "alt": img.get("alt", "No Alt Text")} for img in all_images]

print("\n🔹 Links Data:", links_data)
print("\n🔹 Images Data:", images_data)
