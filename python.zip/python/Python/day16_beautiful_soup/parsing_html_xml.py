from bs4 import BeautifulSoup

# Sample HTML
html_doc = """<html><body><h1>Hello, World!</h1></body></html>"""

# Parse HTML
soup = BeautifulSoup(html_doc, "html.parser")

# Parse XML
xml_doc = """<data><item>Hello XML</item></data>"""
soup_xml = BeautifulSoup(xml_doc, "xml")

print("HTML Parsed:", soup.h1.text)
print("XML Parsed:", soup_xml.item.text)
