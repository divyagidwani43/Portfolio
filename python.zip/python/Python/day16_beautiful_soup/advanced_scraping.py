import requests
from bs4 import BeautifulSoup

url = "https://example.com"
response = requests.get(url)

soup = BeautifulSoup(response.text, "html.parser")

# Extract table data
for row in soup.find_all("tr"):
    cols = row.find_all("td")
    print([col.text for col in cols])

# Extract JavaScript-rendered content (requires Selenium)
# from selenium import webdriver
# driver = webdriver.Chrome()
# driver.get(url)
# soup = BeautifulSoup(driver.page_source, "html.parser")
