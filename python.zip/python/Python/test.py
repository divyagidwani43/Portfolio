# Given a dictionary, swap its keys and values.
#              (example :- {'a': 1, 'b': 2, 'c': 3}
#              output:- {1: 'a', 2: 'b', 3: 'c'})

dict1={'a': 1, 'b': 2, 'c': 3}
dict2={}
for keys,values in dict1.items():
    dict2[values]=keys

print(dict2)

# # Write a function that takes a list and rotates it k times to the right.
# # example:- list = [1,2,3,4,5] , k=2
# #    o/p :- [4, 5, 1, 2, 3]  

# lst2=[]
# def rotating_list(lst,k):
#     for i in range(len(lst)-1):
#         if k>i:
#             lst2[i]=lst[int(len(lst)-1-i)]
#         else:


# Write a function that takes any number of arguments and returns their sum.
# If no arguments are passed, return 0.
def sum(*num):
    if(int(len(num))!=0):
        addition=0
        for nums in num:
            addition+=nums
        return addition
    else:
        return 0
    
# List containing duplicates. remove the duplicates and the result object should be a list
list= [1,2,3,2,4,5,6,6,7,7]
lst3=[]
for elements in list:
    if(elements not in lst3):
        lst3.append(elements)
print(lst3)

# Write a Python function that takes a sentence as input and returns the sentence with each word reversed 
# while keeping the word order the same.   Example Input:  "Hello World Python"
# expected o/p:- olleH dlroW nohtyP

# def reverse_str(str1):
#     str2=str1.split(" ")
#     rev=[]
#     for words in str2:
#         rev.append(words[::-1])
#     return(rev.join(" "))

# reverse_str("Hello World Python")

# Write a function that takes a list of dictionaries containing student names and scores.
# Return the name of the student with the highest score.
students = [
   {"name": "Alice", "score": 85},
   {"name": "Bob", "score": 92},
   {"name": "Charlie", "score": 88}
]
def highest_score(lst):
    score_final=0
    name_final=""
    for dict in lst:
        if score_final<=dict["score"]:
            score_final=dict["score"]
            name_final= dict["name"]
    return name_final

print(highest_score(students))
    
# write some content to a text file. if the file doesn't exist, create it first. if it exists, append the content. use try-except
try:
    file_path="text1.txt"
    with open(file_path, "a") as txt_file:
        txt_file.write("appended content")
except Exception as e:
    print(e)

# OOP program for a Calculator app with add, subtract, multiply and division functionalities
class calculator:
    def __init__(self,a,b):
        a=a
        b=b

    def add(a,b):
        return(a+b)
    
    def substract(a,b):
        return(a-b)
    
    def multiply(a,b):
        return(a*b)
    
    def division(a,b):
        return(a/b)
    
calci=calculator()
calci.add(7,3)

        