# Exercise 4: Create a function with a default argument
# Write a program to create a function show_employee() using the following conditions.
# If the salary is missing in the function call then assign default value 9000 to salary
# showEmployee("Ben", 12000)
# showEmployee("Jessa")
# Name: Ben salary: 12000
# Name: Jessa salary: 9000
def show_employee(name, salary=9000):
    print(f"name: {name}, salary : {salary}")
show_employee("Ben", 12000)
show_employee("Jessa")

# Exercise 5: Create an inner function to calculate the addition in the following way
# Create an outer function that will accept two parameters, a and b
# Create an inner function inside an outer function that will calculate the addition of a and b
# At last, an outer function will add 5 into addition and return it
def outer(a,b):
    def inner():
        c=a+b
        return c
    d = inner() + 5
    return d

print(outer(3,4))

# Exercise 6: Create a recursive function

# Exercise 7: Assign a different name to function and call it through the new name
# Exercise 8: Generate a Python list of all the even numbers between 4 to 30
list6=[]
for i in range(4,30):
    if(i%2==0):
        list6.append(i)
print(list6)
# Exercise 9: Find the largest item from a given list
x = [4, 6, 8, 24, 12, 2]
i=1
y=0
for  i in range(len(x)):
    if(x[i]>y):
        y=x[i]
    i+=1
print(y)
    

    