from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.action_chains import ActionChains
import time

# Set up WebDriver
driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.google.com")
time.sleep(2)

# Browser Operations
driver.get("https://www.python.org")  # Open another page
time.sleep(2)
driver.back()  # Go back
time.sleep(2)
driver.forward()  # Go forward
time.sleep(2)
driver.refresh()  # Refresh the page
time.sleep(2)

# Web Element Interaction
search_box = driver.find_element(By.NAME, "q")  # Locate search box
"""
If the search box has a different attribute, you can locate it using other methods
By ID, Class Name, XPath, CSS Selector - driver.find_element(By.CSS_SELECTOR, "input.search-class")
"""
search_box.send_keys("Selenium Python")  # Type text
search_box.send_keys(Keys.RETURN)  # Press Enter
time.sleep(3)

# Keyboard & Mouse Actions
actions = ActionChains(driver)
element = driver.find_element(By.XPATH, "//a[contains(text(),'Downloads')]")
"""
Finds an <a> tag (hyperlink) containing the text "Downloads" using XPath. //a → Look for all <a> contains(text(),'Downloads')
"""
actions.move_to_element(element).perform()  # Hover over an element, here element is anchor with downloads text
actions.click(element).perform()  # Click on an element
# actions.double_click(element).perform()  # Double click on an element
# actions.drag_and_drop(element, element).perform()  # Drag and drop an element to another element
# time.sleep(2)

# Handling Alerts, Popups & Frames
# Example: Switching to an alert and accepting it
# alert = driver.switch_to.alert
# alert.accept()

# Handling Waits & Timeouts
wait = WebDriverWait(driver, 10) # waits for 10 sec or until the element is located, if located in 2 second wont wait for 10
wait.until(EC.presence_of_element_located((By.NAME, "q")))  # Wait for search bar to be present 

# Web Scraping
results = driver.find_elements(By.CSS_SELECTOR, "h3")
for result in results[:5]:  # Print first 5 results
    print(result.text)

# Handling File Uploads (Example: NotImplemented Here)
# file_input = driver.find_element(By.NAME, "fileUpload")
# file_input.send_keys("C:\\path\\to\\file.txt")

# Automating Forms & Login
# driver.get("https://example.com/login")
# driver.find_element(By.NAME, "username").send_keys("your_username")
# driver.find_element(By.NAME, "password").send_keys("your_password")
# driver.find_element(By.NAME, "login").click()

# Close the browser
driver.quit()
