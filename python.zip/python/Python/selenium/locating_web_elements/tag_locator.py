from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()

driver.get("file://C:/Users/Dell/Desktop/python/Python/selenium/locating_web_elements/login.html")

time.sleep(3)

input_fields = driver.find_elements(By.TAG_NAME, "input")  # Finds all input fields
login_button = driver.find_element(By.TAG_NAME, "button")  # Finds the login button

username = input_fields[0]  # First <input> field (Username)
password = input_fields[1]  # Second <input> field (Password)

username.send_keys("test_user1")
password.send_keys("securePass1234")
login_button.click()
time.sleep(3)

username.clear()
password.clear()

username.send_keys("test_user")
password.send_keys("securePass123")
login_button.click()

time.sleep(3)

driver.quit()
