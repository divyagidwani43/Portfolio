from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, ElementNotInteractableException
driver = webdriver.Chrome()

try:
    driver.get("file://C:/Users/Dell/Desktop/python/Python/selenium/locating_web_elements/login.html")
    time.sleep(2)

    username = driver.find_element(By.CSS_SELECTOR, "input[name='username']")
    password = driver.find_element(By.CSS_SELECTOR, "input[name='password']")
    login_button = driver.find_element(By.CSS_SELECTOR, "button.login-button")

    username.send_keys("test_user1")
    password.send_keys("securePass1234")
    login_button.click()
    time.sleep(2)
    username.clear()
    password.clear()
    username.send_keys("test_user")
    password.send_keys("securePass123")
    login_button.click()
    time.sleep(2)

except TimeoutException:
    print("Error: Element took too long to load.")
except NoSuchElementException:
    print("Error: Element not found.")
except ElementNotInteractableException:
    print("Error: Element is not interactable.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
finally:
    driver.quit()
