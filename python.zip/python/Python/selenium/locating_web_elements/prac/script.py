from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()

driver.get("file:///C:/Users/Dell/Desktop/python/Python/locating_web_elements/prac/index.html")

time.sleep(3)

username = driver.find_element(By.ID, "username")
username.send_keys("test_user")
time.sleep(2)
password = driver.find_element(By.NAME, "password")
password.send_keys("securePass123")
time.sleep(2)
email = driver.find_element(By.CLASS_NAME, "email-field")
email.send_keys("test@example.com")
time.sleep(2)
phone = driver.find_element(By.XPATH, "//input[@id='phone']")
phone.send_keys("1234567890")
time.sleep(2)
country_dropdown = driver.find_element(By.TAG_NAME, "select")
country_dropdown.send_keys("India")
time.sleep(2)
login_button = driver.find_element(By.CSS_SELECTOR, "button.login-btn")
login_button.click()
time.sleep(2)

forgot_password = driver.find_element(By.LINK_TEXT, "Forgot Password?")
forgot_password.click()
time.sleep(2)
driver.back()  

signup_link = driver.find_element(By.PARTIAL_LINK_TEXT, "Create")
signup_link.click()
time.sleep(2)
driver.back()  

time.sleep(3)

driver.quit()
