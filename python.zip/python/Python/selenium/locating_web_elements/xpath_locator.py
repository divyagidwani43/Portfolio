from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# using def instead of sending keys multiple times
def perform_login(username_field, password_field, login_button, username_value, password_value):
    username_field.send_keys(username_value)
    password_field.send_keys(password_value)
    login_button.click()

driver = webdriver.Chrome()
driver.get("file://C:/Users/Dell/Desktop/python/Python/selenium/locating_web_elements/login.html")

time.sleep(3)

username = driver.find_element(By.XPATH, "//input[@name='username']")  # XPath for username input
password = driver.find_element(By.XPATH, "//input[@name='password']")  # XPath for password input
login_button = driver.find_element(By.XPATH, "//button[@class='login-button']")  # XPath for login button

# using function
perform_login(username, password, login_button, "test_user1", "securePass1234")
time.sleep(3)

username.clear()
password.clear()

perform_login(username, password, login_button, "test_user", "securePass123")
time.sleep(3)

driver.quit()
