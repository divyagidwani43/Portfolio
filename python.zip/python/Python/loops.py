# Exercise 1: Print first 10 natural numbers using while loop
x=0
while x<10:
    print(x)
    x+=1
# Exercise 2: Print the following pattern
# 1 
# 1 2 
# 1 2 3 
# 1 2 3 4 
# 1 2 3 4 5
list1=[1,2,3,4,5]
for i in range(1, len(list1)+1):
    for j in range(1,i+1):
        print(j, end=" ")
    print()
    
# Exercise 3: Calculate sum of all numbers from 1 to a given number
print("threeee")
given=6
k=0
for i in range(1,given):
    k+=i
    print(k)

# Exercise 4: Print multiplication table of a given number
print("four")
given2= 5
for i in range(11):
    print(given2*i)

# Exercise 5: Display numbers from a list using a loop
list3=[1,2,3,34,5,6]
for i in range(len(list3)):
    print(list3[i])
# Exercise 6: Count the total number of digits in a number
num = 7716233
count = 0







# for i in range()
# Exercise 7: Print the following pattern
# 5 4 3 2 1 
# 4 3 2 1 
# 3 2 1 
# 2 1 
# 1
list5=[1,2,3,4,5]
print("jeidhhsd")
x2=5
while x2>0:
    x=x2
    while x>0:
        print(x, end=" ")
        x-=1
    print()
    x2-=1

# Exercise 8: Print list in reverse order using a loop
list5 = [10, 20, 30, 40, 50]
for i in range(1,len(list5)+1):
    print(list5[-i])
# Exercise 9: Display numbers from -10 to -1 using for loop
for num in range(-10,0):
    print(num)
# Exercise 10: Display a message “Done” after the successful execution of the for loop
for num in range(-10,0):
    print(num)
else:
    print("done")



# Exercise 13: Find the factorial of a given number
num=4
factorial=1
for i in range(1,num+1):
        print(i)
        factorial*=i
print(factorial)


# Exercise 14: Reverse a integer number
num = 98473
reversed_num = int(str(num)[::-1])
print(reversed_num)

# # Exercise 15: Print elements from a given list present at odd index positions
# 20 40 60 80 100
my_list = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
for i in range(len(my_list)):
    if(i%2!=0):
        print(my_list[i], end=" ")
print()

# # Exercise 16: Calculate the cube of all numbers from 1 to a given number 
given=8
for i in range(given):
    cube=i*i*i
    print(cube, end=" ")
print()

# # Exercise 17: Find the sum of the series up to n terms
# Write a program to calculate the sum of series up to n terms. 
# For example, if n = 5 the series will become 2 + 22 + 222 + 2222 + 22222 = 24690
# number of terms
n = 5
# 24690
sum=0
seq_num=2
l9=[]
seq=""
for i in range(n+1):
    for j in range(i):
        seq=""
        seq+="2"*i
        if(int(seq) not in l9):
            l9.append(int(seq))
print(l9)
sum2=0
for items in l9:
    sum2+=items
print(sum2)

# # Exercise 18: Print the following pattern
# * 
# * * 
# * * * 
# * * * * 
# * * * * * 
# * * * * 
# * * * 
# * * 
# *
pattern="*"
times=5
for i in range(times+1):
    print("*"*i)
    if(i==5):
        x=5
        while x>=1:
            print("*"*x)
            x-=1

print("Stop the loop if x equals 3")  
for i in range(5):  # Loops from 0 to 4
    if i == 3:
        print("Breaking the loop at i =", i)
        break  # Exit the loop when i equals 3
    print(i) #when i not 3 and less than 3


print("")  
print("Skip iteration if x is 2") 
for i in range(5):  
    if i == 2:
        print("Skipping i =", i)
        continue  #wont break but skip only
    print(i)


# Using zip to iterate over multiple lists simultaneously
names = ["Alice", "Bob", "Charlie"]
ages = [25, 30, 35]
for name, age in zip(names, ages):
    print(f"{name} is {age} years old")
print("")