#Write a function square_number(n) that takes a number n and returns its square.
def square(n):
  return n*n
print(square(3))
  
# Write a function multiply_all(*nums) that multiplies all numbers given as arguments
def multiply_all(*nums):
    result = 1  # Start with 1 because multiplying by 1 doesn't change the result
    for num in nums:
        result *= num  # Multiply each number in nums
    return result

print(multiply_all(2, 3))  # Output: 6 (2 * 3)

# Write a function factorial(n) that calculates the factorial of a number n.
def factorial(n):
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers.")
    if n == 0:
        return 1
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# Example usage
print(factorial(5))  # Output: 120

# Edge cases
print(factorial(0))  # Output: 1


# Write a function sum_even_odd(*nums) that accepts a variable number of arguments and calculates the sum of all even numbers and the sum of all odd numbers separately. Return both sums as a tuple (even_sum, odd_sum).
def sum_even_odd(*nums):
    if not nums:  # Check if no numbers are provided
        return 0, 0
    
    even_sum = odd_sum = 0
    for num in nums:
        if num % 2 == 0:
            even_sum += num
        else:
            odd_sum += num
    return even_sum, odd_sum

even_sum, odd_sum = sum_even_odd(1, 2, 3, 4, 5)
print(f"Even Sum: {even_sum}, Odd Sum: {odd_sum}")  # Expected: Even Sum: 6, Odd Sum: 9

even_sum, odd_sum = sum_even_odd()
print(f"Even Sum: {even_sum}, Odd Sum: {odd_sum}")  # Expected: Even Sum: 0, Odd Sum: 0

even_sum, odd_sum = sum_even_odd(2, 4, 6, 8, 10)
print(f"Even Sum: {even_sum}, Odd Sum: {odd_sum}")  # Expected: Even Sum: 30, Odd Sum: 0

even_sum, odd_sum = sum_even_odd(1, 3, 5, 7, 9)
print(f"Even Sum: {even_sum}, Odd Sum: {odd_sum}")  # Expected: Even Sum: 0, Odd Sum: 25

