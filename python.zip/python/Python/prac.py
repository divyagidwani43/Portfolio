""" Write a program to create a function that takes two arguments, name and age, and print their value. """
def one(name,age):
    print(name,age)

"""
Write a program to create function func1() to accept a variable length of arguments and print their value.
Note: Create a function in such a way that we can pass any number of arguments to this function, and the
function should process them and display each argument’s value.
"""
def func1(*argu):
    for num in argu:
        print(num)

func1(2,3,4,5)

"""
Write a program to create function calculation() such that it can accept two variables and 
calculate addition and subtraction. Also, it must return both addition and subtraction in a single return call.
"""
def calculation(a,b):
    add = a+b
    subs = a-b
    return(add,subs)

print(calculation(5,4))