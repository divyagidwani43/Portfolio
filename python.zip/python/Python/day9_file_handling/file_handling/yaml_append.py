import yaml  # Importing the PyYAML library for YAML file handling

try:
    # Step 1: Read the existing YAML file
    with open("data.yaml", "r") as yaml_file:
        existing_data = yaml.safe_load(yaml_file) or {}  
        # Load existing data from the file. If the file is empty, use an empty dictionary.

    # Step 2: Append new data to the existing YAML content
    new_data = {
        "hobbies": ["Reading", "Cycling"],  # Adding a new list of hobbies
        "experience": 5  # Adding experience as an integer value
    }
    existing_data.update(new_data)  # Merge the new data into the existing dictionary

    # Step 3: Write the updated data back to the YAML file
    with open("data.yaml", "w") as yaml_file:
        yaml.dump(existing_data, yaml_file, default_flow_style=False)
        # Dump the updated dictionary into the YAML file in a readable format

    print("YAML file has been updated successfully.")

    # Step 4: Read and display the updated content
    with open("data.yaml", "r") as yaml_file:
        updated_content = yaml.safe_load(yaml_file) or {}
        # Load the modified content to verify the update
        print("\nUpdated YAML File Content:")
        print(updated_content)  # Print the updated YAML content as a dictionary

# Error handling section
except FileNotFoundError:
    print("Error: The YAML file was not found!")  
    # This occurs if the file does not exist when trying to read it
except yaml.YAMLError as e:
    print("YAML Error:", e)  
    # Catches errors related to improper YAML formatting or issues while parsing
except Exception as e:
    print("An unexpected error occurred:", e)  
    # Handles any other unknown exceptions
finally:
    print("\nYAML file modification complete.")  
    # This block executes whether or not an error occurs
